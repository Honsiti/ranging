#include "stm32f10x.h"                  // Device header
#include "Delay.h"                  // Device header
#include "OLED.h" 
#include "HC_SR04.h" 

uint8_t integer_mm,decimal_mm;
uint8_t integer_m,decimal_m;

int main(void)
{
	
	OLED_Init();												//OLED初始化
	HC_SR04_Init();
	OLED_ShowString(1,1,"MM:");
	while(1)
	{	
		OLED_ShowNum(1,5,HC_SR04_Distance_mm(),3);

		
		
		
		
	}
}
