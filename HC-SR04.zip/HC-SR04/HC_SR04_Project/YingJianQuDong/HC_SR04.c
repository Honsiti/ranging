#include "stm32f10x.h"                  // Device header
#include "Delay.h"                    // Device header

uint16_t Coumt=0,Timer_Send,Timer_Read;

void HC_SR04_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);  //RCC_APB2(选择外设，使能/失能)
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;					//GPIO_Mode_Out_PP 推挽输出
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_4 | GPIO_Pin_3 ;									
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure); 
GPIO_ResetBits(GPIOA,GPIO_Pin_3);	

	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;					// 浮空输入
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_2 ;									
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);	
	GPIO_ResetBits(GPIOA,GPIO_Pin_2);
	
	TIM_InternalClockConfig(TIM2);
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1;	//指定参数分频值(选择1分频)，
	TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up;//选择技术模式；
	TIM_TimeBaseInitStructure.TIM_Period=10-1;		//ARR  
	TIM_TimeBaseInitStructure.TIM_Prescaler=72-1;		//PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter=0;
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStructure);			
	
	TIM_ClearFlag(TIM2, TIM_FLAG_Update);   // 清除更新中断，免得一打开中断立即产生中断  
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);   // 打开定时器更新中断  
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannel=TIM2_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=2;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority=2;
	NVIC_Init(&NVIC_InitStruct);
	
	TIM_Cmd(TIM2,DISABLE);
}


//定时中断
void TIM2_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM2,TIM_IT_Update) == SET)
	{
		Coumt++;
		TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
	}
}

void HC_SR04_TIM2Enable(void)
{
//	TIM_SetCounter(TIM2,0);   // 清除计数
	TIM_Cmd(TIM2,ENABLE);
	Timer_Send=Coumt;
}

void HC_SR04_TIM2Off(void)
{
	TIM_Cmd(TIM2,ENABLE);
	Timer_Read=Coumt;
}

int16_t  HC_SR04_Distance_mm(void)
{
	uint8_t Distance,i=0;
	uint8_t Distance_mm=0;
	GPIO_WriteBit(GPIOA,GPIO_Pin_3,Bit_SET);
	Delay_us(15);
	GPIO_WriteBit(GPIOA,GPIO_Pin_3,Bit_RESET);
	while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2) == Bit_RESET)//卡死，
	{
		GPIO_WriteBit(GPIOA,GPIO_Pin_4,Bit_SET);
	}
	HC_SR04_TIM2Enable();
	while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2) == Bit_SET)
	{
		GPIO_WriteBit(GPIOA,GPIO_Pin_4,Bit_SET);
	}
	HC_SR04_TIM2Off();
	if((Timer_Read-Timer_Send)/100<38)
	{
		Distance=((Timer_Read-Timer_Send)*346)/2;
		Distance_mm=Distance/100;
	}
	return Distance_mm;
}
	





////计算单位 mm
//int16_t  HC_SR04_Distance_mm(void)
//{
//	uint8_t Distance;
//	uint8_t Distance_mm=0;
//	uint8_t mm_time_1=0,mm_time_2;
//	GPIO_WriteBit(GPIOA,GPIO_Pin_2,Bit_SET);
//	Delay_us(15);
//	GPIO_WriteBit(GPIOA,GPIO_Pin_2,Bit_RESET);
//	while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1) == Bit_RESET)
//	{
//		GPIO_WriteBit(GPIOA,GPIO_Pin_3,Bit_RESET);
//	}
//	mm_time_1=Coumt;
//	while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1) == Bit_SET)
//	{
//		GPIO_WriteBit(GPIOA,GPIO_Pin_3,Bit_SET);
//	}
//	mm_time_2=Coumt;
//	if((mm_time_2-mm_time_1)/100<38)
//	{
//		Distance=(Timers*346)/2;
//		Distance_mm=Distance/100;
//	}
//	return Distance_mm;
//}

//计算单位 m
//float HC_SR04_Distance_m(void)
//{
//	uint8_t Distance;
//	uint8_t Distance_m;
//	GPIO_WriteBit(GPIOA,GPIO_Pin_2,Bit_SET);
//	Delay_us(15);
//	GPIO_WriteBit(GPIOA,GPIO_Pin_2,Bit_RESET);
//	while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1) == Bit_RESET);
//	Coumt=0;
//	while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1) == Bit_SET);
//	Timers=Coumt;
//	if(Timers/100<38)
//	{
//		Distance=(Timers*346)/2;
//		Distance_m=Distance/1000;
//	}
//	return Distance_m;
//}


//uint8_t TIM_Coumt_1(void)
//{
//	return Coumt1;
//}

//uint8_t TIM_Coumt_2(void)
//{
//	return Coumt;
//}







