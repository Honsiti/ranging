#ifndef __CC_H
#define __CC_H

void Timer_Init(void);
void HC_SR04_Init(void);
int16_t sonar_mm(void)	;

#endif

