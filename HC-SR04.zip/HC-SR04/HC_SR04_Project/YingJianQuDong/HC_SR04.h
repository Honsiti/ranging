#ifndef __HC_SR04_H
#define __HC_SR04_H


void HC_SR04_Init(void);
void TIM2_IRQHandler(void);
void HC_SR04_TIM2Enable(void);
void HC_SR04_TIM2Off(void);
int16_t  HC_SR04_Distance_mm(void);






//float HC_SR04_Distance_m(void);
//int16_t  HC_SR04_Distance_mm(void);
//void HC_SR04_Work(void);
#endif
