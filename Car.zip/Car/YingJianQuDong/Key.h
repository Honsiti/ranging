#ifndef _KEY_H
#define _KEY_H

uint8_t Key_GetNum(void);
void Key_Init(void);



#endif
