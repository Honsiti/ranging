#include "stm32f10x.h"                  // Device header

void PWM_Init()
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);  //开启时钟，TIM2是APB1总线的外设
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);//开启时钟，选择GPIO口
	
	GPIO_InitTypeDef GPIO_InitStructure;
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;//选择推挽输出模式
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_1 ;
 	GPIO_Init(GPIOA, &GPIO_InitStructure);

	
	GPIO_InitTypeDef GPIO_InitStructure1;
 	GPIO_InitStructure1.GPIO_Mode = GPIO_Mode_AF_PP;//选择推挽输出模式
	GPIO_InitStructure1.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure1.GPIO_Pin = GPIO_Pin_0 ;
 	GPIO_Init(GPIOA, &GPIO_InitStructure1);
	
	TIM_InternalClockConfig(TIM2);//配置TIM2内部时钟
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1;		//指定参数分频值(选择1分频)，DIV22分频 DIV4 44分频 
	TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up;//选择技术模式；
	TIM_TimeBaseInitStructure.TIM_Period=100-1;  	//ARR
	TIM_TimeBaseInitStructure.TIM_Prescaler=72-1;		//PSC
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter=0;
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStructure);			//配置时基单元
	
	TIM_OCInitTypeDef TIM_OCInitStructure;
	TIM_OCStructInit(&TIM_OCInitStructure);//整个结构体附初始值，避免出现错误
	TIM_OCInitStructure.TIM_OCMode=TIM_OCMode_PWM1;					//输出比较模式
	TIM_OCInitStructure.TIM_OCPolarity=TIM_OCPolarity_High; //输出比较极性
	TIM_OCInitStructure.TIM_OutputState=TIM_OutputState_Enable;//输出状态，使能or失能
	TIM_OCInitStructure.TIM_Pulse=0;  //设置CCR寄存器的值
	TIM_OC2Init(TIM2,&TIM_OCInitStructure);	//通道选择
	TIM_OC3Init(TIM2,&TIM_OCInitStructure);

	TIM_Cmd(TIM2,ENABLE);
}

void PWM_SetCompare_right(uint16_t Compare)
{
	TIM_SetCompare2(TIM2, Compare);
}


void PWM_SetCompare_left(uint16_t Compare)
{
	TIM_SetCompare3(TIM2, Compare);
}




