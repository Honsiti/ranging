#ifndef _MOTOR_H
#define _MOTOR_H


void Motor_Setspeed_1(int8_t Speed);
void Motor_Setspeed_2(int8_t Speed);
void Motor_Init(void);
void Motor_Go(uint8_t Speed);
void Motor_Stop(void);
void Motor_back(uint8_t Speed);
void Motor_Goright(uint8_t Speed_Right,uint8_t Speed_Left);
void Motor_Goleft(uint8_t Speed_Right,uint8_t Speed_Left);

#endif
