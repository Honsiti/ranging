#ifndef __COUNTSENSOR_H
#define __COUNTSENSOR_H

void CountSensor_Init(void);
//uint16_t CountSensor_Get_1(void);
//uint16_t CountSensor_Get_2(void);

#endif
