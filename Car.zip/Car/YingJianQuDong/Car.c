#include "stm32f10x.h"                  // Device header
#include "CountSensor.h"  
#include "Motor.h" 

uint8_t Count;

void Car_Init(void)
{
	Motor_Init();
	CountSensor_Init();
}


void Car_Go()
{
	

}


void EXTI15_10_IRQHandler()
{
		if(EXTI_GetITStatus(EXTI_Line14)==SET)
		{
			
			EXTI_ClearITPendingBit(EXTI_Line14);
			
		}
		
			if(EXTI_GetITStatus(EXTI_Line15)==SET)
		{

			EXTI_ClearITPendingBit(EXTI_Line15);
		}
}