#include "stm32f10x.h"                  // Device header
#include "PWM.h"                

void Motor_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);					
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IPU;       							
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 |GPIO_Pin_7;					
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;									
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	PWM_Init();
}


void Motor_Go(uint8_t Speed)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_5);
	GPIO_ResetBits(GPIOA,GPIO_Pin_4);
	PWM_SetCompare_right(Speed);
	
	GPIO_SetBits(GPIOA,GPIO_Pin_7);
	GPIO_ResetBits(GPIOA,GPIO_Pin_6);
	PWM_SetCompare_left(Speed);
}

void Motor_Stop(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_5);
	GPIO_SetBits(GPIOA,GPIO_Pin_4);
	
	GPIO_SetBits(GPIOA,GPIO_Pin_7);
	GPIO_SetBits(GPIOA,GPIO_Pin_6);
}

void Motor_back(uint8_t Speed)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_4);
	GPIO_ResetBits(GPIOA,GPIO_Pin_5);
	PWM_SetCompare_right(Speed);
	
	GPIO_SetBits(GPIOA,GPIO_Pin_6);
	GPIO_ResetBits(GPIOA,GPIO_Pin_7);
	PWM_SetCompare_left(Speed);
}


void Motor_Goright(uint8_t Speed_Right,uint8_t Speed_Left)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_5);
	GPIO_ResetBits(GPIOA,GPIO_Pin_4);
	PWM_SetCompare_right(Speed_Right);
	
	GPIO_SetBits(GPIOA,GPIO_Pin_7);
	GPIO_ResetBits(GPIOA,GPIO_Pin_6);
	PWM_SetCompare_left(Speed_Left);
}

void Motor_Goleft(uint8_t Speed_Right,uint8_t Speed_Left)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_5);
	GPIO_ResetBits(GPIOA,GPIO_Pin_4);
	PWM_SetCompare_right(Speed_Right);
	
	GPIO_SetBits(GPIOA,GPIO_Pin_7);
	GPIO_ResetBits(GPIOA,GPIO_Pin_6);
	PWM_SetCompare_left(Speed_Left);
}





