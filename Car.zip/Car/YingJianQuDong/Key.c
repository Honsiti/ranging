#include "stm32f10x.h"                  // Device header
#include "Delay.h"

void Key_Init(void)
{	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);					//	配置时钟信号 RCC_APB2Periph_GPIOx 选择外设地址
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IPU;       								//按键上拉输入模式
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_1 | GPIO_Pin_11;						//选择GPIOB的1、11号引脚
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;									//传输速率50MHZ
	GPIO_Init(GPIOB,&GPIO_InitStruct);

}

uint8_t Key_GetNum(void)
{
	uint8_t KeyNum=0;
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)==0)								//读的是GPIOx的IDR寄存器中的一位数，返回值不是0就是1,读哪一位由参数GPIO_Pin_x决定
	{
		Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)==0);					//检测按键是否一直按下
		Delay_ms(20);
		KeyNum=1;
	}
	
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11)==0)
	{
		Delay_ms(20);
		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11)==0);					//检测按键是否一直按下
		Delay_ms(20);
		KeyNum=2;
	}
	return KeyNum;
}
