#ifndef __PWM_H
#define __PWM_H

void PWM_Init(void);
void PWM_SetCompare_left(uint16_t Compare);
void PWM_SetCompare_right(uint16_t Compare);



#endif
