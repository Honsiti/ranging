#ifndef _TIMER_H_
#define _TIMER_H_

void Timer_Init(void);
void TIM2_IRQHandler(void);
uint16_t Timer_GetCounter(void);

#endif
