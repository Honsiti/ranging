#include "stm32f10x.h"                  // Device header
#include "Delay.h"                  // Device header
#include "CountSensor.h"  
#include "OLED.h" 
#include "Motor.h" 

uint16_t TT;

int main(void)
{
	OLED_Init();
	Motor_Init();
	CountSensor_Init();
//	Motor_Goleft(40);
	while(1)
	{	
		//left
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)==RESET && GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14)==SET) 
		{
			Motor_Goleft(50,20);
			GPIO_SetBits(GPIOA,GPIO_Pin_0);
		}
		else if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)==SET && GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14)==RESET)
		{//right
			Motor_Goright(30,80);
			GPIO_SetBits(GPIOA,GPIO_Pin_9);
		}
		else if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14)==SET && GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)==SET)
		{//goward
			Motor_Go(90);
			GPIO_SetBits(GPIOA,GPIO_Pin_10);
		}
//		else if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14)==RESET && GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)==RESET)
//		{
//			Motor_back(90);
//			GPIO_SetBits(GPIOA,GPIO_Pin_11);
//		}
		else
		{
			Motor_Stop();
		}


	



	}
}

